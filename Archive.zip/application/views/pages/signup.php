<style>
    /* form */
body{
    background:#efefef;
}
.form-body{
    background:#fff;
    padding:20px;
    margin-bottom:40px;
    width:500px;
    padding:30px;
}
.link{
    margin-top:15px;
    padding:20px;
}
.loginlink{
    margin-top:20px;
    font-size:1.5rem;
    font-weight:bold;
}
</style>
        <div id="page-content-wrapper">
            <a href="#menu-toggle" class="menuopener" id="menu-toggle"><i class="fa fa-bars"></i></a>
            <div class="demo-parallax parallax section looking-photo nopadbot" data-stellar-background-ratio="0.5" style="background-image:url('assets/upload/demo_02.jpg');">
                <div class="page-title section nobg">
                    <div class="container-fluid">
                        <div class="clearfix">
                            <div class="title-area pull-left">
                                <h2>SIGNUP  <small>Please sign up to use our sites.</small></h2>
                            </div>
                            <!-- /.pull-right -->
                            <div class="pull-right hidden-xs">
                                <div class="bread">
                                    <ol class="breadcrumb">
                                        <li><a href="#">Home</a></li>
                                        <li class="active">Signup</li>
                                    </ol>
                                </div>
                                <!-- end bread -->
                            </div>
                            <!-- /.pull-right -->
                        </div>
                        <!-- end clearfix -->
                    </div>
                </div>
                <!-- end page-title -->
            </div>

<br>
<br>
<div class="container">
<div class="row">
<div class="col-md-4 col-md-offset-4">
<div class="form-body">
    <div class="row">
        <div class="col-sm-12 col-md-12">
            <h3 class="text-center" style="font-weight:bold;color:#e74c3c">SIGN UP</h3>
            
        </div>
    </div>
    <hr>
    <div class="row link" style="border:1px solid  #D3D3D3">
        <div class="col-sm-12 col-md-12 text-center">
            <a href="<?php echo base_url();?>teachers/register" class="text-center" style="font-size:20px;">I'M A TEACHER</a>
        </div>
    </div>
    <div class="row link" style="border:1px solid  #D3D3D3">
        <div class="col-sm-12 col-md-12 text-center">
            <a href="<?php echo base_url();?>students/register" class="text-center" style="font-size:20px;">I'M A STUDENT</a>
                                </div>
                            </div>
                            <div class="row loginlink text-center">
                            <a href="login.php">Already have a account?Log In</a>
                            </div>
                            
                            </div>
                        
                            
                            

                                </div>
                            
                            </div>
                                          </div>
                                                     </div>
                                                         </div>
                                                             </div>