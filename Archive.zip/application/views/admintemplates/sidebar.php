
<div class="sidebar-main sidebar-menu-one sidebar-expand-md sidebar-color">
               <div class="mobile-sidebar-header d-md-none">
                    <div class="header-logo">
                        <a href="index.php"><img src="<?php echo base_url();?>adminassets/images/logo1.png" alt="logo"></a>
                    </div>
               </div>
                <div class="sidebar-menu-content">
                    <ul class="nav nav-sidebar-menu sidebar-toggle-view">
                        <li class="nav-item sidebar-nav-item">
                            <a href="#" class="nav-link"><i class="flaticon-dashboard"></i><span>Dashboard</span></a>
                            <ul class="nav sub-group-menu">
                                <li class="nav-item">
                                    <a href="index.php" class="nav-link"><i class="fas fa-angle-right"></i>Admin</a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item sidebar-nav-item">
                            <a href="#" class="nav-link"><i class="flaticon-classmates"></i><span>Students</span></a>
                            <ul class="nav sub-group-menu">
                                <li class="nav-item">
                                    <a href="<?php echo base_url();?>admin/allstudents" class="nav-link"><i class="fas fa-angle-right"></i>All
                                        Students</a>
                                </li>
                                
                               
                            </ul>
                        </li>
                        <li class="nav-item sidebar-nav-item">
                            <a href="#" class="nav-link"><i
                                    class="flaticon-multiple-users-silhouette"></i><span>Teachers</span></a>
                            <ul class="nav sub-group-menu">
                                <li class="nav-item">
                                    <a href="<?php echo base_url();?>admin/allteachers" class="nav-link"><i class="fas fa-angle-right"></i>All
                                        Teachers</a>
                                </li>
                                
                                
                                
                            </ul>
                        </li>
                        <li class="nav-item sidebar-nav-item">
                            <a href="#" class="nav-link"><i
                                    class="flaticon-books"></i><span>Subjects</span></a>
                            <ul class="nav sub-group-menu">
                                <li class="nav-item">
                                <a href="<?php echo base_url();?>admin/allsubjects" class="nav-link"><i class="fas fa-angle-right"></i>
                                        Subjects</a>
                                    <a href="<?php echo base_url();?>admin/addsubjects" class="nav-link"><i class="fas fa-angle-right"></i>Add
                                        Subjects</a>
                                </li>
                            </ul>
                        </li>
                        
						<li class="nav-item">
                            <a href="payment.php" class="nav-link"><i
                                class="fas fa-angle-right"></i>Payment</a>
                        </li>
                        
                    </ul>
                </div>
            </div>