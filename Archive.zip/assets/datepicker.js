
    $("#dateinput").datepicker({
        numberOfMonths:1,
        changeYear:true,
        changeMonth:true,
        showWeek:true,
        weekHeader:"Week number",
        showOtherMonths:true,
        yearRange: "1980:2040"
    });
